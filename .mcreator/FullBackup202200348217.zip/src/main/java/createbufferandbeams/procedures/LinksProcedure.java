package createbufferandbeams.procedures;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.network.chat.TextComponent;

import java.util.Map;

import createbufferandbeams.CreatebufferandbeamsMod;

public class LinksProcedure {

	public static void execute(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				CreatebufferandbeamsMod.LOGGER.warn("Failed to load dependency entity for procedure Links!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		if (entity instanceof Player _player && !_player.level.isClientSide())
			_player.displayClientMessage(new TextComponent(
					"Thanks for choosing CB&B Curseforge: https://www.curseforge.com/minecraft/mc-mods/create-buffers-beams Github: https://github.com/createbufferandbeams"),
					(false));
	}
}
