/*
 *	MCreator note:
 *
 *	If you lock base mod element files, you can edit this file and the proxy files
 *	and they won't get overwritten. If you change your mod package or modid, you
 *	need to apply these changes to this file MANUALLY.
 *
 *
 *	If you do not lock base mod element files in Workspace settings, this file
 *	will be REGENERATED on each build.
 *
 */
package createbufferandbeams;

import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;

import net.fabricmc.api.ModInitializer;

import createbufferandbeams.init.CreatebufferandbeamsModTabs;
import createbufferandbeams.init.CreatebufferandbeamsModProcedures;
import createbufferandbeams.init.CreatebufferandbeamsModMenus;
import createbufferandbeams.init.CreatebufferandbeamsModItems;
import createbufferandbeams.init.CreatebufferandbeamsModCommands;
import createbufferandbeams.init.CreatebufferandbeamsModBlocks;

public class CreatebufferandbeamsMod implements ModInitializer {
	public static final Logger LOGGER = LogManager.getLogger();
	public static final String MODID = "createbufferandbeams";

	@Override
	public void onInitialize() {
		LOGGER.info("Initializing CreatebufferandbeamsMod");
		CreatebufferandbeamsModTabs.load();

		CreatebufferandbeamsModBlocks.load();
		CreatebufferandbeamsModItems.load();

		CreatebufferandbeamsModProcedures.load();
		CreatebufferandbeamsModCommands.load();

		CreatebufferandbeamsModMenus.load();

	}
}
