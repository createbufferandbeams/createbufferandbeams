
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package createbufferandbeams.init;

import net.minecraft.world.inventory.MenuType;
import net.minecraft.resources.ResourceLocation;

import net.fabricmc.fabric.api.screenhandler.v1.ScreenHandlerRegistry;

import createbufferandbeams.world.inventory.GUIMenu;

import createbufferandbeams.client.gui.GUIScreen;

import createbufferandbeams.CreatebufferandbeamsMod;

public class CreatebufferandbeamsModMenus {
	public static MenuType<GUIMenu> GUI;

	public static void load() {
		GUI = ScreenHandlerRegistry.registerExtended(new ResourceLocation(CreatebufferandbeamsMod.MODID, "gui"), GUIMenu::new);
		GUIScreen.screenInit();
	}
}
