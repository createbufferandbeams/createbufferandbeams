
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package createbufferandbeams.init;

import net.fabricmc.fabric.api.command.v1.CommandRegistrationCallback;

import createbufferandbeams.command.GuicommandCommand;
import createbufferandbeams.command.CreatebufferbeamsCommand;

public class CreatebufferandbeamsModCommands {
	public static void load() {
		CommandRegistrationCallback.EVENT.register((dispatcher, dedicated) -> {
			CreatebufferbeamsCommand.register(dispatcher);
			GuicommandCommand.register(dispatcher);
		});
	}
}
