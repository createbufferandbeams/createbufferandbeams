
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package createbufferandbeams.init;

import net.minecraft.world.level.block.Block;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.Registry;

import createbufferandbeams.block.WhistleBlock;
import createbufferandbeams.block.ThrottleBlock;
import createbufferandbeams.block.RunningBoardBlock;
import createbufferandbeams.block.RedBufferBlock;
import createbufferandbeams.block.MiddleBoardBlock;
import createbufferandbeams.block.MericanHeadLampBlock;
import createbufferandbeams.block.LNERSignBlock;
import createbufferandbeams.block.LMSSignBlock;
import createbufferandbeams.block.HeadlampBrownBlock;
import createbufferandbeams.block.HeadLampBlock;
import createbufferandbeams.block.HandbrakeBlock;
import createbufferandbeams.block.GoldFunnelBlock;
import createbufferandbeams.block.GWRSignBlock;
import createbufferandbeams.block.FunnelBlock;
import createbufferandbeams.block.BufferBeamBlock;
import createbufferandbeams.block.BritishTailampBlock;
import createbufferandbeams.block.BritishLampBlock;
import createbufferandbeams.block.BoilerBlock;

import createbufferandbeams.CreatebufferandbeamsMod;

public class CreatebufferandbeamsModBlocks {
	public static Block WHISTLE;
	public static Block HANDBRAKE;
	public static Block BRITISH_LAMP;
	public static Block BRITISH_TAILAMP;
	public static Block RED_BUFFER;
	public static Block HEAD_LAMP;
	public static Block BOILER;
	public static Block MIDDLE_BOARD;
	public static Block RUNNING_BOARD;
	public static Block GOLD_FUNNEL;
	public static Block MERICAN_HEAD_LAMP;
	public static Block FUNNEL;
	public static Block HEADLAMP_BROWN;
	public static Block GWR_SIGN;
	public static Block LMS_SIGN;
	public static Block LNER_SIGN;
	public static Block BUFFER_BEAM;
	public static Block THROTTLE;

	public static void load() {
		WHISTLE = Registry.register(Registry.BLOCK, new ResourceLocation(CreatebufferandbeamsMod.MODID, "whistle"), new WhistleBlock());
		HANDBRAKE = Registry.register(Registry.BLOCK, new ResourceLocation(CreatebufferandbeamsMod.MODID, "handbrake"), new HandbrakeBlock());
		BRITISH_LAMP = Registry.register(Registry.BLOCK, new ResourceLocation(CreatebufferandbeamsMod.MODID, "british_lamp"), new BritishLampBlock());
		BRITISH_TAILAMP = Registry.register(Registry.BLOCK, new ResourceLocation(CreatebufferandbeamsMod.MODID, "british_tailamp"),
				new BritishTailampBlock());
		RED_BUFFER = Registry.register(Registry.BLOCK, new ResourceLocation(CreatebufferandbeamsMod.MODID, "red_buffer"), new RedBufferBlock());
		HEAD_LAMP = Registry.register(Registry.BLOCK, new ResourceLocation(CreatebufferandbeamsMod.MODID, "head_lamp"), new HeadLampBlock());
		BOILER = Registry.register(Registry.BLOCK, new ResourceLocation(CreatebufferandbeamsMod.MODID, "boiler"), new BoilerBlock());
		MIDDLE_BOARD = Registry.register(Registry.BLOCK, new ResourceLocation(CreatebufferandbeamsMod.MODID, "middle_board"), new MiddleBoardBlock());
		RUNNING_BOARD = Registry.register(Registry.BLOCK, new ResourceLocation(CreatebufferandbeamsMod.MODID, "running_board"),
				new RunningBoardBlock());
		GOLD_FUNNEL = Registry.register(Registry.BLOCK, new ResourceLocation(CreatebufferandbeamsMod.MODID, "gold_funnel"), new GoldFunnelBlock());
		MERICAN_HEAD_LAMP = Registry.register(Registry.BLOCK, new ResourceLocation(CreatebufferandbeamsMod.MODID, "merican_head_lamp"),
				new MericanHeadLampBlock());
		FUNNEL = Registry.register(Registry.BLOCK, new ResourceLocation(CreatebufferandbeamsMod.MODID, "funnel"), new FunnelBlock());
		HEADLAMP_BROWN = Registry.register(Registry.BLOCK, new ResourceLocation(CreatebufferandbeamsMod.MODID, "headlamp_brown"),
				new HeadlampBrownBlock());
		GWR_SIGN = Registry.register(Registry.BLOCK, new ResourceLocation(CreatebufferandbeamsMod.MODID, "gwr_sign"), new GWRSignBlock());
		LMS_SIGN = Registry.register(Registry.BLOCK, new ResourceLocation(CreatebufferandbeamsMod.MODID, "lms_sign"), new LMSSignBlock());
		LNER_SIGN = Registry.register(Registry.BLOCK, new ResourceLocation(CreatebufferandbeamsMod.MODID, "lner_sign"), new LNERSignBlock());
		BUFFER_BEAM = Registry.register(Registry.BLOCK, new ResourceLocation(CreatebufferandbeamsMod.MODID, "buffer_beam"), new BufferBeamBlock());
		THROTTLE = Registry.register(Registry.BLOCK, new ResourceLocation(CreatebufferandbeamsMod.MODID, "throttle"), new ThrottleBlock());
	}

	public static void clientLoad() {
		WhistleBlock.clientInit();
		HandbrakeBlock.clientInit();
		BritishLampBlock.clientInit();
		BritishTailampBlock.clientInit();
		RedBufferBlock.clientInit();
		HeadLampBlock.clientInit();
		BoilerBlock.clientInit();
		MiddleBoardBlock.clientInit();
		RunningBoardBlock.clientInit();
		GoldFunnelBlock.clientInit();
		MericanHeadLampBlock.clientInit();
		FunnelBlock.clientInit();
		HeadlampBrownBlock.clientInit();
		GWRSignBlock.clientInit();
		LMSSignBlock.clientInit();
		LNERSignBlock.clientInit();
		BufferBeamBlock.clientInit();
		ThrottleBlock.clientInit();
	}
}
