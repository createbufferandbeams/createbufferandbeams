
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package createbufferandbeams.init;

import createbufferandbeams.procedures.LinksProcedure;
import createbufferandbeams.procedures.GuitestProcedure;

@SuppressWarnings("InstantiationOfUtilityClass")
public class CreatebufferandbeamsModProcedures {
	public static void load() {
		new LinksProcedure();
		new GuitestProcedure();
	}
}
