
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package createbufferandbeams.init;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.Registry;

import createbufferandbeams.CreatebufferandbeamsMod;

public class CreatebufferandbeamsModItems {
	public static Item WHISTLE;
	public static Item HANDBRAKE;
	public static Item BRITISH_LAMP;
	public static Item BRITISH_TAILAMP;
	public static Item RED_BUFFER;
	public static Item HEAD_LAMP;
	public static Item BOILER;
	public static Item MIDDLE_BOARD;
	public static Item RUNNING_BOARD;
	public static Item GOLD_FUNNEL;
	public static Item MERICAN_HEAD_LAMP;
	public static Item FUNNEL;
	public static Item HEADLAMP_BROWN;
	public static Item GWR_SIGN;
	public static Item LMS_SIGN;
	public static Item LNER_SIGN;
	public static Item BUFFER_BEAM;
	public static Item THROTTLE;

	public static void load() {
		WHISTLE = Registry.register(Registry.ITEM, new ResourceLocation(CreatebufferandbeamsMod.MODID, "whistle"), new BlockItem(
				CreatebufferandbeamsModBlocks.WHISTLE, new Item.Properties().tab(CreatebufferandbeamsModTabs.TAB_CREATE_BUFFER_AND_BEAMS)));
		HANDBRAKE = Registry.register(Registry.ITEM, new ResourceLocation(CreatebufferandbeamsMod.MODID, "handbrake"), new BlockItem(
				CreatebufferandbeamsModBlocks.HANDBRAKE, new Item.Properties().tab(CreatebufferandbeamsModTabs.TAB_CREATE_BUFFER_AND_BEAMS)));
		BRITISH_LAMP = Registry.register(Registry.ITEM, new ResourceLocation(CreatebufferandbeamsMod.MODID, "british_lamp"), new BlockItem(
				CreatebufferandbeamsModBlocks.BRITISH_LAMP, new Item.Properties().tab(CreatebufferandbeamsModTabs.TAB_CREATE_BUFFER_AND_BEAMS)));
		BRITISH_TAILAMP = Registry.register(Registry.ITEM, new ResourceLocation(CreatebufferandbeamsMod.MODID, "british_tailamp"), new BlockItem(
				CreatebufferandbeamsModBlocks.BRITISH_TAILAMP, new Item.Properties().tab(CreatebufferandbeamsModTabs.TAB_CREATE_BUFFER_AND_BEAMS)));
		RED_BUFFER = Registry.register(Registry.ITEM, new ResourceLocation(CreatebufferandbeamsMod.MODID, "red_buffer"), new BlockItem(
				CreatebufferandbeamsModBlocks.RED_BUFFER, new Item.Properties().tab(CreatebufferandbeamsModTabs.TAB_CREATE_BUFFER_AND_BEAMS)));
		HEAD_LAMP = Registry.register(Registry.ITEM, new ResourceLocation(CreatebufferandbeamsMod.MODID, "head_lamp"), new BlockItem(
				CreatebufferandbeamsModBlocks.HEAD_LAMP, new Item.Properties().tab(CreatebufferandbeamsModTabs.TAB_CREATE_BUFFER_AND_BEAMS)));
		BOILER = Registry.register(Registry.ITEM, new ResourceLocation(CreatebufferandbeamsMod.MODID, "boiler"), new BlockItem(
				CreatebufferandbeamsModBlocks.BOILER, new Item.Properties().tab(CreatebufferandbeamsModTabs.TAB_CREATE_BUFFER_AND_BEAMS)));
		MIDDLE_BOARD = Registry.register(Registry.ITEM, new ResourceLocation(CreatebufferandbeamsMod.MODID, "middle_board"), new BlockItem(
				CreatebufferandbeamsModBlocks.MIDDLE_BOARD, new Item.Properties().tab(CreatebufferandbeamsModTabs.TAB_CREATE_BUFFER_AND_BEAMS)));
		RUNNING_BOARD = Registry.register(Registry.ITEM, new ResourceLocation(CreatebufferandbeamsMod.MODID, "running_board"), new BlockItem(
				CreatebufferandbeamsModBlocks.RUNNING_BOARD, new Item.Properties().tab(CreatebufferandbeamsModTabs.TAB_CREATE_BUFFER_AND_BEAMS)));
		GOLD_FUNNEL = Registry.register(Registry.ITEM, new ResourceLocation(CreatebufferandbeamsMod.MODID, "gold_funnel"), new BlockItem(
				CreatebufferandbeamsModBlocks.GOLD_FUNNEL, new Item.Properties().tab(CreatebufferandbeamsModTabs.TAB_CREATE_BUFFER_AND_BEAMS)));
		MERICAN_HEAD_LAMP = Registry.register(Registry.ITEM, new ResourceLocation(CreatebufferandbeamsMod.MODID, "merican_head_lamp"), new BlockItem(
				CreatebufferandbeamsModBlocks.MERICAN_HEAD_LAMP, new Item.Properties().tab(CreatebufferandbeamsModTabs.TAB_CREATE_BUFFER_AND_BEAMS)));
		FUNNEL = Registry.register(Registry.ITEM, new ResourceLocation(CreatebufferandbeamsMod.MODID, "funnel"), new BlockItem(
				CreatebufferandbeamsModBlocks.FUNNEL, new Item.Properties().tab(CreatebufferandbeamsModTabs.TAB_CREATE_BUFFER_AND_BEAMS)));
		HEADLAMP_BROWN = Registry.register(Registry.ITEM, new ResourceLocation(CreatebufferandbeamsMod.MODID, "headlamp_brown"), new BlockItem(
				CreatebufferandbeamsModBlocks.HEADLAMP_BROWN, new Item.Properties().tab(CreatebufferandbeamsModTabs.TAB_CREATE_BUFFER_AND_BEAMS)));
		GWR_SIGN = Registry.register(Registry.ITEM, new ResourceLocation(CreatebufferandbeamsMod.MODID, "gwr_sign"), new BlockItem(
				CreatebufferandbeamsModBlocks.GWR_SIGN, new Item.Properties().tab(CreatebufferandbeamsModTabs.TAB_CREATE_BUFFER_AND_BEAMS)));
		LMS_SIGN = Registry.register(Registry.ITEM, new ResourceLocation(CreatebufferandbeamsMod.MODID, "lms_sign"), new BlockItem(
				CreatebufferandbeamsModBlocks.LMS_SIGN, new Item.Properties().tab(CreatebufferandbeamsModTabs.TAB_CREATE_BUFFER_AND_BEAMS)));
		LNER_SIGN = Registry.register(Registry.ITEM, new ResourceLocation(CreatebufferandbeamsMod.MODID, "lner_sign"), new BlockItem(
				CreatebufferandbeamsModBlocks.LNER_SIGN, new Item.Properties().tab(CreatebufferandbeamsModTabs.TAB_CREATE_BUFFER_AND_BEAMS)));
		BUFFER_BEAM = Registry.register(Registry.ITEM, new ResourceLocation(CreatebufferandbeamsMod.MODID, "buffer_beam"), new BlockItem(
				CreatebufferandbeamsModBlocks.BUFFER_BEAM, new Item.Properties().tab(CreatebufferandbeamsModTabs.TAB_CREATE_BUFFER_AND_BEAMS)));
		THROTTLE = Registry.register(Registry.ITEM, new ResourceLocation(CreatebufferandbeamsMod.MODID, "throttle"), new BlockItem(
				CreatebufferandbeamsModBlocks.THROTTLE, new Item.Properties().tab(CreatebufferandbeamsModTabs.TAB_CREATE_BUFFER_AND_BEAMS)));
	}
}
