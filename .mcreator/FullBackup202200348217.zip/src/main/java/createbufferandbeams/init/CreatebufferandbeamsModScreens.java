
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package createbufferandbeams.init;

import net.fabricmc.fabric.api.client.screenhandler.v1.ScreenRegistry;

import createbufferandbeams.client.gui.GUIScreen;

public class CreatebufferandbeamsModScreens {
	public static void load() {
		ScreenRegistry.register(CreatebufferandbeamsModMenus.GUI, GUIScreen::new);
	}
}
