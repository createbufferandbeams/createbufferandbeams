
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package createbufferandbeams.init;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.resources.ResourceLocation;

import net.fabricmc.fabric.api.client.itemgroup.FabricItemGroupBuilder;

public class CreatebufferandbeamsModTabs {
	public static CreativeModeTab TAB_CREATE_BUFFER_AND_BEAMS;

	public static void load() {
		TAB_CREATE_BUFFER_AND_BEAMS = FabricItemGroupBuilder.create(new ResourceLocation("createbufferandbeams", "create_buffer_and_beams"))
				.icon(() -> new ItemStack(CreatebufferandbeamsModBlocks.BUFFER_BEAM)).build();
	}
}
