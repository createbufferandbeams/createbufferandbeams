
package createbufferandbeams.command;

import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.Direction;
import net.minecraft.commands.Commands;
import net.minecraft.commands.CommandSourceStack;

import createbufferandbeams.procedures.LinksProcedure;

import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.CommandDispatcher;

public class CreatebufferbeamsCommand {
	public static void register(CommandDispatcher<CommandSourceStack> dispatcher, CommandContext commandBuildContext) {
		dispatcher.register(Commands.literal("cbblinks")

				.executes(arguments -> {
					ServerLevel world = arguments.getSource().getLevel();
					double x = arguments.getSource().getPosition().x();
					double y = arguments.getSource().getPosition().y();
					double z = arguments.getSource().getPosition().z();
					Entity entity = arguments.getSource().getEntity();
					Direction direction = entity.getDirection();

					LinksProcedure.execute(com.google.common.collect.ImmutableMap.<String, Object>builder().put("entity", entity).build());
					return 0;
				}));
	}
}
